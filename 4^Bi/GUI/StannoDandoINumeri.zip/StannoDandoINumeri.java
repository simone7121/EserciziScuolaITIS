/*

    Algoritmo:      Realizzare un’applicazione Java con l’uso
                    di finestre di popup per gestire dei
                    numeri casuali letti dall'utente.

    Programmatore:  Simone D'Anna
    Data:           03/05/2022
    Versione:       V 1.0

*/

import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class StannoDandoINumeri {

    static Random random = new Random();

    public static void main(String[] args) throws IOError {

        int scelta = 0;

        Object[] possibleValues = { "Facile", "Intermedio", "Difficile" };

        do {

            Object selectInput = JOptionPane.showInputDialog(null,
                    "[ BENVENUTO A Stanno Dando I Numeri ! ]\n\nScegli La difficoltà ", "Scelta",
                    JOptionPane.INFORMATION_MESSAGE, new ImageIcon("images/Roulette.png"), possibleValues,
                    possibleValues[0]);

            if (selectInput != null) {

                indovinaNumeri(selectInput.toString());
                scelta = JOptionPane.showConfirmDialog(null, "Vuoi uscire dal programma ?", "Scelta",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE);

            }

            if (selectInput == null) { // alla pressione di Annulla oppure dell’icona di uscita

                scelta = JOptionPane.showConfirmDialog(null, "Vuoi uscire dal programma ?", "Scelta",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE);

            }

        } while (scelta == JOptionPane.NO_OPTION);

    }

    private static void indovinaNumeri(String difficolta) {

        int scelta;
        int numgen;
        int max;
        int min;
        final int maxTentativi = 5;

        if (difficolta.equals("Facile")) {
            max = 20;
            min = 1;
        } else if (difficolta.equals("Intermedio")) {
            max = 50;
            min = 1;
        } else if (difficolta.equals("Difficile")) {
            max = 69;
            min = 1;
        } else {
            max = 1;
            min = 1;
        }

        do {

            numgen = genNumCasuale(max, min);

            JOptionPane.showMessageDialog(null, "NUMERO DA " + min + " A " + max + "\n GENERATO CORRETTAMENTE !");   // icona
                                                                                                                                    // di
                                                                                                                                    // tipo
                                                                                                                                    // "Informazione"

            System.out.println(numgen);

            for (int i = 0; i < maxTentativi; i++) {

                int numero = Integer.parseInt(JOptionPane.showInputDialog("Hai a disposizione ( " + (maxTentativi - i)
                        + " TENTATIVI/O )\nInserisci un numero Compreso tra [" + min + " - " + max + "]\n"));

                if (numero > max || numero < min) {

                    JOptionPane.showMessageDialog(null, "VALORE INSERITO NON RIENTRA NELL'INTERVALLO!", "Sbagliato",
                            JOptionPane.ERROR_MESSAGE);
                    i--;

                } else {

                    if (numgen < numero) {

                        JOptionPane.showMessageDialog(null,
                                "VALORE INSERITO ( " + numero + " )\nMAGGIORE DEL NUMERO ESTRATTO!", "Sbagliato !",
                                JOptionPane.ERROR_MESSAGE, new ImageIcon("images/Close_Icon.png"));

                    } else if (numgen > numero) {

                        JOptionPane.showMessageDialog(null,
                                "VALORE INSERITO ( " + numero + " )\nMINORE DEL NUMERO ESTRATTO!", "Sbagliato !",
                                JOptionPane.ERROR_MESSAGE, new ImageIcon("images/Close_Icon.png"));

                    } else if (numero == numgen) {
                        JOptionPane.showMessageDialog(null,
                                "VALORE INSERITO ( " + numero + " )\nCORRISPONDE AL NUMERO ESTRATTO!\n HAI VINTO !!!",
                                "CORRETTO !", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("images/Tick_Mark.png"));
                        i = maxTentativi;
                    }

                }

            }

            scelta = JOptionPane.showConfirmDialog(null, "Vuoi continuare a giocare ?", "Scelta",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE);

        } while (scelta != JOptionPane.NO_OPTION);
    }

    private static int genNumCasuale(int max, int min) {

        return random.nextInt(max + min) - min;

    }

}
/*
 * ____/\\\\\\\\\\\__________/\\\\\\\\\\\\___________________
 * ____/\\\/////////\\\_______\/\\\////////\\\_______________
 * ____\//\\\______\///________\/\\\______\//\\\_____________
 * ______\////\\\_______________\/\\\_______\/\\\____________
 * __________\////\\\____________\/\\\_______\/\\\___________
 * ______________\////\\\_________\/\\\_______\/\\\__________
 * _______/\\\______\//\\\________\/\\\_______/\\\___________
 * ________\///\\\\\\\\\\\/____/\\\_\/\\\\\\\\\\\\/____/\\\__
 * ___________\///////////_____\///__\////////////_____\///__
 */
